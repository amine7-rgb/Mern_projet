module.exports = {
    secret: "agricom-secret-key"
  };